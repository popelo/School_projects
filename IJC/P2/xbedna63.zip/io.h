// Filip Bednár
// xbedna63
// VUT FIT
// príklad (b 
// 14.4.2016

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

int get_word( char *s, int max, FILE *f );


