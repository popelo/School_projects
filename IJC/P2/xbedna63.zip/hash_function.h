// Filip Bednár
// xbedna63
// VUT FIT
// príklad (b
// 14.4.2016

#include <stdlib.h>
#include <stdio.h>

  unsigned int hash_function( const char *str, unsigned htab_size );

